package com.promosport.app.service;

import com.promosport.app.model.Match;
import com.promosport.app.model.Pari;

import java.util.List;
import java.util.Optional;

public interface MatchService {

    Optional<Match> trouverParId(Long id);

    Match mettreAJourResultat(Long matchId, String resultatEquipeA, String resultatEquipeB);

    void mettreAJourResultatPari(Match match);

    // Autres méthodes que vous pourriez avoir besoin d'ajouter
    Match creerMatch(Match match);
    Match modifierMatch(Long id, Match matchDetails);
    void supprimerMatch(Long id);
    List<Match> listerMatchs();
}
