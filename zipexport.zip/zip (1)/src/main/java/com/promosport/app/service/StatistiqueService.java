package com.promosport.app.service;

import com.promosport.app.model.Statistique;
import java.util.List;

public interface StatistiqueService {
    Statistique creerStatistique(Statistique statistique);
    List<Statistique> listerStatistiques();
    Statistique trouverParId(Long id);
    Statistique modifierStatistique(Long id, Statistique statistiqueDetails);
    void supprimerStatistique(Long id);
}
