package com.promosport.app.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class Pari {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private double montant;
    private double cote; // Cote européenne
    private String typePari;
    private String resultat;
    private boolean gagne; // Nouveau champ pour indiquer si le pari est gagné

    @ManyToOne
    private Utilisateur utilisateur;

    @ManyToOne
    private Match match;

    // Getters et Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public double getMontant() {
        return montant;
    }

    public void setMontant(double montant) {
        this.montant = montant;
    }

    public double getCote() {
        return cote;
    }

    public void setCote(double cote) {
        this.cote = cote;
    }

    public String getTypePari() {
        return typePari;
    }

    public void setTypePari(String typePari) {
        this.typePari = typePari;
    }

    public String getResultat() {
        return resultat;
    }

    public void setResultat(String resultat) {
        this.resultat = resultat;
    }

    public boolean isGagne() {
        return gagne;
    }

    public void setGagne(boolean gagne) {
        this.gagne = gagne;
    }

    public Utilisateur getUtilisateur() {
        return utilisateur;
    }

    public void setUtilisateur(Utilisateur utilisateur) {
        this.utilisateur = utilisateur;
    }

    public Match getMatch() {
        return match;
    }

    public void setMatch(Match match) {
        this.match = match;
    }

    @Override
    public String toString() {
        return "Pari{" +
                "id=" + id +
                ", montant=" + montant +
                ", cote=" + cote +
                ", typePari='" + typePari + '\'' +
                ", resultat='" + resultat + '\'' +
                ", gagne=" + gagne +
                ", utilisateur=" + utilisateur +
                ", match=" + match +
                '}';
    }
}
