package com.promosport.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParisSportifApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParisSportifApplication.class, args);
	}

}
