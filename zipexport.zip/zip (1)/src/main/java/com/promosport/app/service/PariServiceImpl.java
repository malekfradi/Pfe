package com.promosport.app.service;

import com.promosport.app.Exception.ResourceNotFoundException;
import com.promosport.app.model.Match;
import com.promosport.app.model.Pari;
import com.promosport.app.repository.MatchRepository;
import com.promosport.app.repository.PariRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PariServiceImpl implements PariService {

    @Autowired
    private PariRepository pariRepository;

    @Override
    public Pari creerPari(Pari pari) {
        if (pari.getUtilisateur().getSolde() >= pari.getMontant()) {
            double nouveauSolde = pari.getUtilisateur().getSolde() - pari.getMontant();
            pari.getUtilisateur().setSolde(nouveauSolde);
            return pariRepository.save(pari);
        } else {
            throw new IllegalArgumentException("Solde insuffisant");
        }
    }

    @Override
    public Optional<Pari> trouverParId(Long id) {
        return pariRepository.findById(id);
    }

    @Override
    public List<Pari> listerParis() {
        return pariRepository.findAll();
    }

    @Override
    public Pari modifierPari(Long id, Pari pariDetails) {
        Pari pari = pariRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Pari non trouvé pour cet id :: " + id));
        pari.setMontant(pariDetails.getMontant());
        pari.setCote(pariDetails.getCote());
        pari.setTypePari(pariDetails.getTypePari());
        pari.setResultat(pariDetails.getResultat());
        pari.setGagne(pariDetails.isGagne());
        return pariRepository.save(pari);
    }

    @Override
    public void supprimerPari(Long id) {
        Pari pari = pariRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Pari non trouvé pour cet id :: " + id));
        pariRepository.delete(pari);
    }

    @Override
    public double calculerGains(double montant, double cote) {
        return montant * cote;
    }

    @Override
    public double calculerProbabilite(double cote) {
        return (1 / cote) * 100;
    }

    @Override
    public void mettreAJourResultatPari(Long matchId) {
        Optional<Match> matchOpt = MatchRepository.findById(matchId);
        if (matchOpt.isPresent()) {
            Match match = matchOpt.get();
            List<Pari> paris = pariRepository.findByMatch(match);
            for (Pari pari : paris) {
                boolean estGagnant = false;
                if (pari.getTypePari().equals("A") && match.getResultatEquipeA().equals("victoire")) {
                    estGagnant = true;
                } else if (pari.getTypePari().equals("B") && match.getResultatEquipeB().equals("victoire")) {
                    estGagnant = true;
                }

                if (estGagnant) {
                    double montantGagne = pari.getMontant() * pari.getCote();
                    pari.setResultat("gagné");
                    pari.setMontantGagne(montantGagne);
                } else {
                    pari.setResultat("perdu");
                }
                pariRepository.save(pari);
            }
        } else {
            throw new ResourceNotFoundException("Match non trouvé pour cet id :: " + matchId);
        }
    }
}
