package com.promosport.app.model;

import jakarta.persistence.*;
import java.util.Set;

@Entity
public class Sport {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nom;

    @OneToMany(mappedBy = "sport")
    private Set<Match> matchs;

    // Getters and setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public Set<Match> getMatchs() {
        return matchs;
    }

    public void setMatchs(Set<Match> matchs) {
        this.matchs = matchs;
    }
}
