package com.promosport.app.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import java.time.LocalDateTime;

@Entity
public class Match {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String equipeA;
    private String equipeB;
    private LocalDateTime date;

    private String resultatEquipeA; // Exemple : "2" (buts marqués par l'équipe A)
    private String resultatEquipeB; // Exemple : "1" (buts marqués par l'équipe B)

    // Getters et Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEquipeA() {
        return equipeA;
    }

    public void setEquipeA(String equipeA) {
        this.equipeA = equipeA;
    }

    public String getEquipeB() {
        return equipeB;
    }

    public void setEquipeB(String equipeB) {
        this.equipeB = equipeB;
    }

    public LocalDateTime getDate() {
        return date;
    }

    public void setDate(LocalDateTime date) {
        this.date = date;
    }

    public String getResultatEquipeA() {
        return resultatEquipeA;
    }

    public void setResultatEquipeA(String resultatEquipeA) {
        this.resultatEquipeA = resultatEquipeA;
    }

    public String getResultatEquipeB() {
        return resultatEquipeB;
    }

    public void setResultatEquipeB(String resultatEquipeB) {
        this.resultatEquipeB = resultatEquipeB;
    }

    @Override
    public String toString() {
        return "Match{" +
                "id=" + id +
                ", equipeA='" + equipeA + '\'' +
                ", equipeB='" + equipeB + '\'' +
                ", date=" + date +
                ", resultatEquipeA='" + resultatEquipeA + '\'' +
                ", resultatEquipeB='" + resultatEquipeB + '\'' +
                '}';
    }
}
