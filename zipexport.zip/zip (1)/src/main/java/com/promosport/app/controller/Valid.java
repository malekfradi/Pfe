package com.promosport.app.controller;

public @interface Valid {
}
