package com.promosport.app.model;

import jakarta.persistence.*;
import java.util.Set;

@Entity
public class Utilisateur {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String login;
    private String motDePasse;
    private String email;
    private String role; // USER or ADMIN
    private double solde; // Solde de l'utilisateur en dinar tunisien

    @OneToMany(mappedBy = "utilisateur")
    private Set<Paiement> paiements;

    @OneToMany(mappedBy = "utilisateur")
    private Set<Pari> paris;

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getMotDePasse() {
        return motDePasse;
    }

    public void setMotDePasse(String motDePasse) {
        this.motDePasse = motDePasse;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public double getSolde() {
        return solde;
    }

    public void setSolde(double solde) {
        this.solde = solde;
    }

    public Set<Paiement> getPaiements() {
        return paiements;
    }

    public void setPaiements(Set<Paiement> paiements) {
        this.paiements = paiements;
    }

    public Set<Pari> getParis() {
        return paris;
    }

    public void setParis(Set<Pari> paris) {
        this.paris = paris;
    }
}
