package com.promosport.app;

import org.junit.jupiter.api.Test;


class ParisSportifApplicationTests {

	@Test
	void contextLoads() {
	}

}
