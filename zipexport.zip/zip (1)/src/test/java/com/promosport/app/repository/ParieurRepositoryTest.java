package com.promosport.app.repository;

class ParieurRepositoryTest {

}